# Fake News Detection Using R

R mini project: **Logistic Regression** + **Decision Tree** to classify a news article as FAKE or REAL from text features (word_count, avg_word_len, exclam_count, caps_ratio, question_count, source_cred, title_len).

## Folder
```
fake_news_r/
├── Fake_News_Detection_Using_R.pptx   <- presentation
├── main.R                 <- full project code
├── install_packages.R     <- installs required packages
├── run.bat / run.sh       <- one-click run (Windows / Mac-Linux)
├── data/news_articles.csv
└── outputs/               <- created on run (plots + model_metrics.csv)
```

## How to run
1. Install R from https://cran.r-project.org (RStudio optional).
2. **Windows:** double-click `run.bat`  |  **Mac/Linux:** `./run.sh`
   Or in a terminal inside this folder:
   ```
   Rscript install_packages.R
   Rscript main.R
   ```
3. RStudio: open `main.R`, set working directory to this folder
   (Session > Set Working Directory > To Source File Location), then click **Source**.

First run installs packages, so it needs internet and takes a few minutes.

## Dataset
`data/news_articles.csv` is a **synthetic demo dataset** (6,025 rows, with a few missing values and
duplicates on purpose for the cleaning stage). To use real data, keep the same column
names and replace the CSV. Slide numbers are approximate and may differ slightly from your run.
