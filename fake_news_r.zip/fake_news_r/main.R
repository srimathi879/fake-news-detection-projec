# =====================================================================
#  Fake News Detection Using R
#  Mini project : Logistic Regression + Decision Tree
#  Run from the project folder:   Rscript main.R
# =====================================================================
library(dplyr)
library(ggplot2)
library(caret)
library(rpart)
library(rpart.plot)
library(pROC)

dir.create("outputs", showWarnings = FALSE)
set.seed(123)

# ---------------------------------------------------------------------
# 1. LOAD DATASET
# ---------------------------------------------------------------------
df <- read.csv("data/news_articles.csv", na.strings = c("NA", ""))

df <- df %>% select(word_count, avg_word_len, exclam_count, caps_ratio,
                    question_count, source_cred, title_len, label)

cat("\n--- Stage 0: Dataset ---\n")
print(head(df))
cat("Dimensions:", dim(df), "\n")
str(df)

# ---------------------------------------------------------------------
# 2. DATA CLEANING
# ---------------------------------------------------------------------
cat("\n--- Stage 1: Data cleaning ---\n")
cat("Missing values per column:\n")
print(colSums(is.na(df)))

df <- df %>% filter(!is.na(label))                         # label missing -> drop
df$source_cred[is.na(df$source_cred)] <- median(df$source_cred, na.rm = TRUE)
cat("NA left after cleaning:", sum(is.na(df)), "\n")

cat("Duplicate rows:", sum(duplicated(df)), "\n")
df <- df[!duplicated(df), ]
cat("Rows after cleaning:", nrow(df), "\n")

# FAKE is the 2nd level, so glm() models the probability of FAKE
df$label <- factor(df$label, levels = c("REAL", "FAKE"))
print(table(df$label))
print(summary(df))

# ---------------------------------------------------------------------
# 3. DATA VISUALIZATION  (plots saved in outputs/)
# ---------------------------------------------------------------------
cols <- c(REAL = "steelblue", FAKE = "firebrick")

p1 <- ggplot(df, aes(word_count, fill = label)) +
  geom_histogram(bins = 40, alpha = .6, position = "identity") +
  scale_fill_manual(values = cols) +
  labs(title = "Word count by label") + theme_minimal()
ggsave("outputs/01_word_count_by_label.png", p1, width = 7, height = 4)

p2 <- ggplot(df, aes(label, exclam_count, fill = label)) +
  geom_boxplot() +
  scale_fill_manual(values = cols) +
  labs(title = "Exclamation marks by label")
ggsave("outputs/02_exclamation_boxplot.png", p2, width = 7, height = 4)

num <- df %>% select(-label)
num$is_fake <- as.numeric(df$label == "FAKE")
cor_mat <- cor(num)
cat("\nCorrelation with FAKE label:\n")
print(round(cor_mat[, "is_fake"], 2))

png("outputs/03_correlation_matrix.png", width = 800, height = 700)
corrplot::corrplot(cor_mat, method = "color")
dev.off()

# ---------------------------------------------------------------------
# 4. DATA SPLITTING  (80% train / 20% test)
# ---------------------------------------------------------------------
idx   <- createDataPartition(df$label, p = 0.8, list = FALSE)
train <- df[idx, ]
test  <- df[-idx, ]
cat("\nTrain rows:", nrow(train), " Test rows:", nrow(test), "\n")

# ---------------------------------------------------------------------
# 5. MODEL TRAINING
# ---------------------------------------------------------------------
# Model 1: Logistic Regression
glm_model <- glm(label ~ word_count + avg_word_len + exclam_count +
                   caps_ratio + question_count + source_cred + title_len,
                 data = train, family = binomial)

# Model 2: Decision Tree
tree_model <- rpart(label ~ ., data = train, method = "class",
                    control = rpart.control(maxdepth = 4))

# ---------------------------------------------------------------------
# 6. LOGISTIC REGRESSION RESULTS
# ---------------------------------------------------------------------
cat("\n===== Logistic Regression =====\n")
print(summary(glm_model))

prob <- predict(glm_model, test, type = "response")
cls  <- factor(ifelse(prob > 0.5, "FAKE", "REAL"), levels = c("REAL", "FAKE"))
cm1  <- confusionMatrix(cls, test$label, positive = "FAKE")
print(cm1)

roc1 <- roc(test$label, prob, levels = c("REAL", "FAKE"), direction = "<")
auc1 <- as.numeric(auc(roc1))
cat(sprintf("AUC = %.3f\n", auc1))

png("outputs/04_roc_curve.png", width = 700, height = 600)
plot(roc1, col = "red", lwd = 2, main = "ROC curve - Logistic Regression")
dev.off()

# ---------------------------------------------------------------------
# 7. DECISION TREE RESULTS
# ---------------------------------------------------------------------
cat("\n===== Decision Tree =====\n")
printcp(tree_model)

png("outputs/05_decision_tree.png", width = 900, height = 650)
rpart.plot(tree_model, main = "Decision Tree - Fake News")
dev.off()

pred_tree <- predict(tree_model, test, type = "class")
cm2 <- confusionMatrix(pred_tree, test$label, positive = "FAKE")
print(cm2)

prob_tree <- predict(tree_model, test, type = "prob")[, "FAKE"]
auc2 <- as.numeric(auc(roc(test$label, prob_tree,
                           levels = c("REAL", "FAKE"), direction = "<")))
cat(sprintf("AUC = %.3f\n", auc2))

# ---------------------------------------------------------------------
# 8. MODEL COMPARISON + SAVE METRICS
# ---------------------------------------------------------------------
get <- function(cm) round(c(unname(cm$overall["Accuracy"]),
                            unname(cm$byClass["Precision"]),
                            unname(cm$byClass["Recall"])), 3)
metrics <- data.frame(
  Model = c("Logistic Regression", "Decision Tree"),
  rbind(c(get(cm1), round(auc1, 3)), c(get(cm2), round(auc2, 3)))
)
names(metrics) <- c("Model", "Accuracy", "Precision", "Recall", "AUC")
print(metrics)
write.csv(metrics, "outputs/model_metrics.csv", row.names = FALSE)

# ---------------------------------------------------------------------
# 9. DEMO: check a new article
# ---------------------------------------------------------------------
new_article <- data.frame(word_count = 250, avg_word_len = 4.6,
                          exclam_count = 6, caps_ratio = 0.15,
                          question_count = 3, source_cred = 2.0,
                          title_len = 16)
p_fake <- predict(glm_model, new_article, type = "response")
cat(sprintf("\nNew article -> probability FAKE: %.1f%%  => %s\n",
            100 * p_fake, ifelse(p_fake > 0.5, "FAKE", "REAL")))
cat("\nDone. Plots and metrics are in the outputs/ folder.\n")
